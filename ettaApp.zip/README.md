# ettaApp
Client app for ETTA

Download/Clone repo then npm install to get all necessary packages.
To run: react-native run-android or react-native run-ios
